// CS405Mod4ExceptionsCK.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>
#include <string>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    CustomException(const std::string& message) : msg(message) {}

    virtual const char* what() const noexcept override {
        return msg.c_str();
    }

private:
    std::string msg;
};

bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception
    throw std::runtime_error("Standard runtime error occurred in even more custom logic.");

    return true;
}
void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catch standard exception and print message
        std::cerr << "Caught std::exception in custom application logic: " << e.what() << std::endl;
    }

    // Throw a custom exception
    throw CustomException("Custom exception thrown in custom application logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den) {
    // Throw an exception for divide-by-zero using standard invalid_argument
    if (den == 0) {
        throw std::invalid_argument("Division by zero is not allowed.");
    }

    return (num / den);
}

void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        float result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        // Catch only the divide-by-zero exception
        std::cerr << "Caught division exception: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    // Wrap main in try-catch to catch all exceptions in correct order
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ce) {
        std::cerr << "Caught custom exception in main: " << ce.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Caught standard exception in main: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Caught unknown exception in main." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu